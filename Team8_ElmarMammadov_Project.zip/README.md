# FinaProject

This program get input from ikea.csv file and the provides utility to play with data from the file. User can filter, search, sort the data from the file. The sorting, filtering and searching are done according to all fields. The program also gives you an opportunity to export your result as .csv file. The program prevents false entering of numbers. 
